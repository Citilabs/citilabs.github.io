In this directory, there are 4 sets of binaries. These represent builds of the 
OMXLib library built with Visual Studio 2013 and Visual Studio 2015 and built 
for box x86 (32-bit) and x64 (64-bit) platforms. 

These are provided for convenience. The choice of which Visual Studio build 
should not matter. For most users, only the 32-bit or 64-bit factor matters. 
You must choose the matching platform for the Python version you intend to use.
If you are using a 32-bit Python version, choose the 32-bit wrapper, similarly 
for 64-bit Python. 

Within each folder contained in this directory is a directory called "omx".
This is the Python package for OMXLib. You may use this package simply
by copying the "omx" folder into your Python distribution's site-packages
folder. For instance, if your Python version is installed in:

C:\Python27

Then you may copy the "omx" folder into this directory:

C:\Python27\Lib\site-packages

So that you have a directory representing the package as:

C:\Python27\Lib\site-packages\omx

Then you may start a Python interpreter session and enter:

import omx

If it returns within no error, then you have successfully configured your
environment.

